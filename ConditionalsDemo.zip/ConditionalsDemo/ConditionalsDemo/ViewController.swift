//
//  ViewController.swift
//  ConditionalsDemo
//
//  Created by  on 10/13/20.
//  Copyright © 2020 BoBoApps. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var myLabel: UILabel!
    
    @IBOutlet weak var myTextField: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    
    @IBAction func buttonTapped(_ sender: UIButton)
    {
        let numericalGrade = Int(myTextField.text ?? "") ?? 0
        myLabel.text = getLetterGrade(percent: numericalGrade)
        
    }
    
    func getLetterGrade(percent: Int) -> String
    {
        if percent >= 90
        {
            return "A"
        }
        if percent >= 80
        {
            return "B"
        }
        if percent >= 70
        {
            return "C"
        }
        if percent >= 60
        {
            return "D"
        }
        else
        {
            return "F"
        }
    }
    
    
}

// && = And
// || = Or
// ! = not or the opposite
